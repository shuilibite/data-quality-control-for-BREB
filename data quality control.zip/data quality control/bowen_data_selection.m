%This program was developed to control the quality of 
%measurement data by Bowen ratio-energy balance method 
%based on the criteria proposed by Perez et al 1999
%------------------reference----------%
%Perez, P., Castellvi, F., Ibanez, M., Rosell, J., 1999. 
%Assessment of reliability of Bowen ratio method for partitioning fluxes. 
%Agricultural and Forest Meteorology 97, 141-151
%--------------Authors----------------%
%Rangjian Qiu and Zhihao Jing
%last update: Nov. 7, 2018
%-------------Cite--------------------%
%If the code is useful, please cite as
% Qiu et al.,2019. Evapotranspiration estimation using a modified Priestley-Taylor model in a rice-wheat rotation system
%Agricultural Water Management,224,
% the data file was organized as follows:
%1        2        3   4       5                 6           7             8   9
%Date, Time, Rn, G, VP_upper, VP-lower, Bowe_ratio, ET  H

clear all
clc
a = xlsread('test_data.xlsx');          %read excel data
[M,N]=size(a);                              %M is row, N is column
Rn=a(:,3);                                     % net radiation (W/m2)
G=a(:,4);                                       % ground soil heat flux (W/m2)
DeltaE=a(:,6)-a(:,5);                       % vapoure pressure difference down-up (kPa)
bowen_ratio=a(:,7);                       % bowen ratio
Row_ET=8;                                    % row of ET data
Row_H=9;                                     % row of H data
ET=a(:,Row_ET);                             % latent heat flux (W/m2)
H=a(:,Row_H);                               % sensibe heat flux (W/m2)
n=24*6;                                         % total  measurement data for each parameter per day(10min measurement interval,i.e. 144 here)
b=[];                                             %storage parameter
%-------------direction judgment--------------%
dir1=find((Rn-G)>0&DeltaE>0&0>=bowen_ratio>-1&ET>0&H<=0);
dir2=find((Rn-G)>0&DeltaE>0&bowen_ratio>0&ET>0&H>0);
dir3=find((Rn-G)>0&DeltaE<0&bowen_ratio<-1&ET<0&H>0);
dir4=find((Rn-G)<0&DeltaE>0&bowen_ratio<-1&ET>0&H<0);
dir5=find((Rn-G)<0&DeltaE<0&0>=bowen_ratio>-1&ET<0&H>=0);
dir6=find((Rn-G)<0&DeltaE<0&bowen_ratio>0&ET<0&H<0);
%-----total numbers of data agreed with direction judgment
sum_dir=length(dir1)+length(dir2)+length(dir3)+length(dir4)+length(dir5)+length(dir6);
%------ratio of data did not agree with direction judgment
ratio_dir=(M-sum_dir)/M;
%-----assign the data did not agree with direction judgment to NaN
for j=1:M
    q=ismember(j,dir1);
    w=ismember(j,dir2);
    e=ismember(j,dir3);
    r=ismember(j,dir4);
    t=ismember(j,dir5);
    y=ismember(j,dir6);
    if q==1||w==1||e==1||r==1||t==1||y==1
           b(j,Row_ET)=a(j,Row_ET);
           b(j,Row_H)=a(j,Row_H); 
    else
          b(j,Row_ET)=nan; 
          b(j,Row_H)=nan;
    end     
end
%------------------rejection region------------%
delta_T= 0.2;        % resolution limit of temperature gradients =2*accuracy of T  (oC)
delta_VP=0.0246; % resolution limit of vapour pressure gradients =2*accuracy of vapour pressure  (kPa)
Pa=100;                % air pressure (Kpa)
gamma=0.665*Pa/1000; %the psychrometric constant with temperature (kPa/oC)
accuracy=delta_VP-gamma*delta_T; %based on instrument accuracy
epsilon=accuracy./DeltaE(:,1); 
refuse1=find((Rn-G)>0&DeltaE>0&bowen_ratio<(-1+abs(epsilon)));
refuse2=find((Rn-G)>0&DeltaE<0&bowen_ratio>(-1-abs(epsilon)));
refuse3=find((Rn-G)<0&DeltaE>0&bowen_ratio>(-1-abs(epsilon)));
refuse4=find((Rn-G)<0&DeltaE<0&bowen_ratio<(-1+abs(epsilon)));
%----assigning the data in rejection region to NaN-----%
b(refuse1,Row_ET:Row_H)=nan;
b(refuse2,Row_ET:Row_H)=nan;
b(refuse3,Row_ET:Row_H)=nan;
b(refuse4,Row_ET:Row_H)=nan;
% total numbers of data in rejection region
ratio_refuse=(length(refuse1)+length(refuse2)+length(refuse3)+length(refuse4));
% total number of false(NaN) date
false_data=length(find(isnan(b(:,Row_ET))));
% total ratio of useful number
ratio_total=(M-false_data)/M;
%---Interpolate missing data using relationship between ET and (Rn-G) every 4-day interval---------
ET_4d=reshape(b(:,Row_ET),4*n,[]);
H_4d =reshape(b(:,Row_H),4*n,[]);
Rn_4d=reshape(Rn-G,4*n,[]);
 for i=1:(M/(4*n))
     false=find(isnan(ET_4d(:,i)));   %find data equal to NaN
     Rn_4d_R(:,i)=Rn_4d(:,i);          
     Rn_4d_R(false,i) = nan;           %assign data of Rn-G to NaN when ET is nan
  %---linear fitting ET as a function of Rn-G without NaN data 
    p1=polyfit(Rn_4d_R(~isnan(Rn_4d_R(:,i)),i),ET_4d(~isnan(ET_4d(:,i)),i),1); 
   %--- fill missing ET
    ET_R(:,i)=polyval(p1,Rn_4d(:,i));
   %---fitting sensible heat flux using energy balance method
    H_R(:,i)=Rn_4d(:,i)-ET_R(:,i);
    ET_c(:,i) = ET_4d(:,i);
    H_c(:,i)=H_4d(:,i);
    ET_c(false,i)=ET_R(false,i);   
    H_c(false,i)=H_R(false,i);
 end
 %----------------Store data-------------------
b(:,Row_ET+2)=reshape(ET_c,[ ],1);
b(:,Row_H+2)=reshape(H_c,[ ],1);
b(:,1:Row_ET-1)=a(:,1:Row_ET-1);
xlswrite('test_data_output.xlsx',b); 

